<footer>
{!! \App\Http\Controllers\Controller::getAddress() !!}
    </footer>